/**
*
* Venegas Guerrero Fatima Alejandra
* Programa que  genera figuras solidas y de malla 
* Con ayuda de un menu se le puede asignar el color que se desea
* El menu sale al hacer cick derecho al raton 
* Salir con la tecla q o Q 
*/


/**
*Se importan las librerias que se requieren en IOS
*/
#ifdef __APPLE_CC__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <cmath>
#include<stdio.h>
#include<math.h>
#include<stdlib.h>

//variable que nos ayudara a darle la rotacion
#define ROT_INC		0.1
int wind2;
float scale = 1.0f;

//Funcion que dibujara la esfera por deafulr
void drawSphere(void);
//Variables para la rotacion
static GLfloat rotar = 0;
static GLfloat g_rotInc = ROT_INC;

//variable que nos ayuda a "seccionar" la siguiente
//figura a dibujar por default esta la esfera
static void (*drawPrimP)(void) = drawSphere;

//Nos ayudara a asignar el color con ayuda del rgb
struct GLColor {
    GLfloat red;
    GLfloat green;
    GLfloat blue;
};

//Arreglo donde se guardaran los colores que se pueden elegir
GLColor colors[6] = {
    {0.0f, 0.0f, 0.0f}, // Negro
    {1.0f, 0.0f, 0.0f}, // Rojo
    {0.0f, 1.0f, 0.0f}, // Verde
    {0.0f, 0.0f, 1.0f}, // Azul
    {1.0f, 1.0f, 0.0f}, // Amarillo
    {1.0f, 0.0f, 1.0f} // Morado
};

GLColor color = colors[0]; //Por default  es color negro

//Funcion que dibuja la esfera por defaulr
void drawSphere(void){ 

//se limpia
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue); //se le asigna el color por default-negro
    glutWireSphere(6.0,20,20);// se dibuja la esfera
}
//Funcion que dibuja el solido de la esfera 
void drawSSphere(void){
    
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//se asigan el color por default
    glutSolidSphere(6.0,20,20);//se dibuja la esfera
}

//Funcion que dibuja un cubo 
void drawCube(void){

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por default
    glutWireCube(6.0);//dibuja el cuadro
}

//Funcion que dibuja un cubo solido 
void drawSCube(void){

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por defualt 
    glutSolidCube(6.0);//se dibuja el cubo 
}
//Funcion que dibuja un cono
void drawCone(void){

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna color por default
    glutWireCone(6.0, 8.0, 10, 20);//dibuja el cono 
}

//Funcion que dibuja el cono -solido
void drawSCone(void){

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna color por default
    glutSolidCone(6.0, 8.0, 10, 20);//dibuja el cono
}

//Funcion que dibuja el Toro
void drawTorus(void){

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna color por default
    glutWireTorus(1.0, 6.0, 10, 20);//dibuja el toro
}

//dibuja el toro solido 
void drawSTorus(void){

    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por defualt
    glutSolidTorus(1.0, 6.0, 10, 20);
}

//Dibuja el iscosaedro
void drawIcos(void){


    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por defualt
    glPushMatrix();
    glScalef(6.0,6.0,6.0);
    glutWireIcosahedron();
    glPopMatrix();
}

//Dibuja el icosaedro solido
void drawSIcos(void){


    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por defualt
    glPushMatrix();
    glScalef(6.0,6.0,6.0);
    glutSolidIcosahedron();
    glPopMatrix();
}

//Dibuja la tetera
void drawTeapot(void){
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por defualt
    glutWireTeapot(6.0);
    glFlush();
}

//Dibuja la tetera solida
void drawSTeapot(void){


    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(color.red, color.green, color.blue);//asigna el color por defualt
    glutSolidTeapot(6.0);
}


void drawSnowMan() {

	glScalef(scale, scale, scale);
	glColor3f(0.0f, 1.0f, 0.0f);

// Draw Body
	glTranslatef(0.0f ,0.75f, 0.0f);
	glutSolidSphere(0.75f,20,20);

// Draw Head
	glTranslatef(0.0f, 1.0f, 0.0f);
	glutSolidSphere(0.25f,20,20);

// Draw Eyes
	glPushMatrix();
	glColor3f(0.0f,0.0f,0.0f);
	glTranslatef(0.05f, 0.10f, 0.18f);
	glutSolidSphere(0.05f,10,10);
	glTranslatef(-0.1f, 0.0f, 0.0f);
	glutSolidSphere(0.05f,10,10);
	glPopMatrix();

// Draw Nose
	glColor3f(color.red, color.green, color.blue);
	glRotatef(0.0f,1.0f, 0.0f, 0.0f);
	glutSolidCone(0.08f,0.5f,10,2);

	glColor3f(1.0f, 1.0f, 1.0f);
}

//Pasada un valor "badera" para elegir la funcion que dibujara la figura
void setPrim(int value)
{
    switch(value)
    {
    case 1:
        drawPrimP = drawSphere;
        break;
    case 2:
        drawPrimP = drawCube;
        break;
    case 3:
        drawPrimP = drawCone;
        break;
    case 4:
        drawPrimP = drawTorus;
        break;
    case 5:
        drawPrimP = drawIcos;
        break;
    case 6:
        drawPrimP = drawTeapot;
        break;
    case 7:
        drawPrimP = drawSSphere;
        break;
    case 8:
        drawPrimP = drawSCube;
        break;
    case 9:
        drawPrimP = drawSCone;
        break;
    case 10:
        drawPrimP = drawSTorus;
        break;
    case 11:
        drawPrimP = drawSIcos;
        break;
    case 12:
        drawPrimP = drawSTeapot;
        break;
    default:
        break;
    }
}

//LO MOSTRAMOS 
void display(void)
{
    glClearColor(1.0f, 1.0f, 1.0f, 0);
    glColor3f(color.red, color.green, color.blue);//NEGRO POR DEFULT
    glMatrixMode(GL_MODELVIEW);

    glPushMatrix();
    glRotatef(rotar,1.0,1.0,1.0);//que rote
    (*drawPrimP)();
    glPopMatrix();
    glutSwapBuffers();
}

void myReshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective( 60.0, (GLdouble)w/(GLdouble)h, 0.1, 40.0);//Algulo de vision
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0.0, 0.0, 20.0,0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

//Para poder salir del programa 
void myKey(unsigned char k, int x, int y)
{
    switch (k)
    {
    case 'q':
    case 'Q':
        exit(0);
        break;
    default:
        break;
    }
}



void myMouse(int btn, int state, int x, int y)
{
    glutPostRedisplay();
}
//FUncion que ayuda a rotar las figuras
void myIdleFunc(void)
{
    rotar += g_rotInc;
    glutPostRedisplay();
}

//FUncion que nos ayuda a manejar los colores 
void subMenuHandler(int choice) {
    color = colors[choice];
}


int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Fa_Paint");


    glutReshapeFunc(myReshape);
    glutDisplayFunc(display);
    glutIdleFunc(myIdleFunc);
    glutKeyboardFunc(myKey);
    glutMouseFunc(myMouse);



//Creamos el menu de las figuras solidas
    int solidos;
    solidos=glutCreateMenu(setPrim);
    glutAddMenuEntry("Esfera Solida",7);
    glutAddMenuEntry("Cubo Solido",8);
    glutAddMenuEntry("Cono Solido",9);
    glutAddMenuEntry("Toroide Solido",10);
    glutAddMenuEntry("Icosaedro Solido",11);
    glutAddMenuEntry("Teapot Solido",12);
    //menú con el click derecho

//Creamos el menu con los colores
    int subMenu = glutCreateMenu(subMenuHandler);
    glutAddMenuEntry("Default", 0);
    glutAddMenuEntry("Rojo", 1);
    glutAddMenuEntry("Verde", 2);
    glutAddMenuEntry("Azul", 3);
    glutAddMenuEntry("Amarillo", 4);
    glutAddMenuEntry("Morado", 5);

//Menu de entrada de las figuras de malla
    glutCreateMenu(setPrim);
    glutAddMenuEntry("Esfera", 1);
    glutAddMenuEntry("Cubo", 2);
    glutAddMenuEntry("Cono", 3);
    glutAddMenuEntry("Toroide", 4);
    glutAddMenuEntry("Icosaedro", 5);
    glutAddMenuEntry("Teapot", 6);
    glutAddSubMenu("Solidos", solidos);
    glutAddSubMenu("Colores", subMenu);
    glutAttachMenu(GLUT_RIGHT_BUTTON);



    glClearColor(1.0, 1.0, 1.0, 1.0);
    glColor3f(0.0, 0.0, 0.0);

   

    glutMainLoop();

    return 0;
}