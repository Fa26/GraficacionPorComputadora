/**
*Venegas Guerrero Fatima Alejandra 
*
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#ifdef __APPLE_CC__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

int alto=888,ancho=500;//dim imagen
int altoP1=512,anchoP1=512;
int bandera =0;
float a=0, b=0.02;
static float salto = 0.0, rotar=0;
static float lightAngle = -0.5, lightHeight = 8;
GLfloat angle = -150;
GLfloat angle2 = 30;
int moving, startx, starty;


static GLdouble tamanio = 6.0;
static GLfloat posicionLuz[4];
static GLfloat colorLuz[] = {1, 1.0, 1, 1.0};
static GLfloat planoPiso[4];
static GLfloat sombraPiso[4][4];

enum {X, Y, Z, W};
enum {A, B, C, D};
unsigned char * imagenPiso;
unsigned char * imagenTecho;
unsigned char * imagenPared1;
unsigned char * imagenPared2;
unsigned char * imagenPared3;
unsigned char * imagenPared4;


 /*Se declara un objeto que almacena una superficie cuadrica.*/
    GLUquadricObj *quad;
    /*Se hace la instancia del objeto.*/

//piso
int leerImagen(){
    FILE *imagen;
    imagen=fopen("im7.ppm","r"); //textura sintetica
    imagenPiso=(unsigned char*)malloc(ancho*alto*3);
    if(imagen==NULL){
        printf("Error: No imagen");
        return 0;
    }
    fread(imagenPiso,ancho*alto*3,1,imagen);
    fclose(imagen);
    return 1;
}

int leerImagenTecho(){
    FILE *imagen;
    imagen=fopen("im7.ppm","r");
    imagenTecho=(unsigned char*)malloc(ancho*alto*3);
    if(imagen==NULL){
        printf("Error: No imagen");
        return 0;
    }
    fread(imagenTecho,ancho*alto*3,1,imagen);
    fclose(imagen);
    return 1;
}

int leerImagenPared1(){
    FILE *fp;
    int  ch, i;

    if ((fp = fopen("im9.ppm", "r")) == NULL){
        fprintf(stderr, "Cannot open ppm file %s\n");
        //exit(1);
    }
        imagenPared1=(unsigned char*)malloc(ancho*alto*3);

    fread(imagenPared1, anchoP1*altoP1*3, 1,fp);   // read RGB data
    fclose(fp);
   
}

//percianas
int leerImagenPared2(){
    FILE *imagen;
    //im90 para poner las percianas
    imagen=fopen("im9.ppm","r");
    imagenPared2=(unsigned char*)malloc(ancho*alto*3);
    if(imagen==NULL){
        printf("Error: No imagen");
        return 0;
    }
    fread(imagenPared2,anchoP1*altoP1*3,1,imagen);
    fclose(imagen);
    return 1;
}

int leerImagenPared3(){
    FILE *imagen;
    imagen=fopen("im9.ppm","r");
    imagenPared3=(unsigned char*)malloc(ancho*alto*3);
    if(imagen==NULL){
        printf("Error: No imagen");
        return 0;
    }
    fread(imagenPared3,ancho*alto*3,1,imagen);
    fclose(imagen);
    return 1;
}

int leerImagenPared4(){
    FILE *imagen;
    imagen=fopen("im9.ppm","r");
    imagenPared4=(unsigned char*)malloc(ancho*alto*3);
    if(imagen==NULL){
        printf("Error: No imagen");
        return 0;
    }
    fread(imagenPared4,ancho*alto*3,1,imagen);
    fclose(imagen);
    return 1;
}
void texturaPiso(void)
{
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, ancho, alto, 0, GL_RGB, GL_UNSIGNED_BYTE, imagenPiso);
}

void texturaTecho(void)
{
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, ancho, alto, 0, GL_RGB, GL_UNSIGNED_BYTE, imagenTecho);
}

int walls=512;

void texturaPared1(void)
{
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, walls, walls, 0, GL_RGB, GL_UNSIGNED_BYTE, imagenPared1);
}

void texturaPared2(void)
{
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, walls, walls, 0, GL_RGB, GL_UNSIGNED_BYTE, imagenPared2);
}
void texturaPared3(void)
{

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, walls, walls, 0, GL_RGB, GL_UNSIGNED_BYTE, imagenPared3);
}
void texturaPared4(void)
{

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, walls, walls, 0, GL_RGB, GL_UNSIGNED_BYTE, imagenPared4);
}

/* Create a matrix that will project the desired shadow. */
void shadowMatrix(GLfloat shadowMat[4][4],
             GLfloat groundplane[4],
             GLfloat lightpos[4])
{
    GLfloat dot;

    // Producto punto entre vector light position y la normal de ground plane
    dot = groundplane[X] * lightpos[X] +
    groundplane[Y] * lightpos[Y] +
    groundplane[Z] * lightpos[Z] +
    groundplane[W] * lightpos[W];

    shadowMat[0][0] = dot - lightpos[X] * groundplane[X];
    shadowMat[1][0] = 0.f - lightpos[X] * groundplane[Y];
    shadowMat[2][0] = 0.f - lightpos[X] * groundplane[Z];
    shadowMat[3][0] = 0.f - lightpos[X] * groundplane[W];

    shadowMat[X][1] = 0.f - lightpos[Y] * groundplane[X];
    shadowMat[1][1] = dot - lightpos[Y] * groundplane[Y];
    shadowMat[2][1] = 0.f - lightpos[Y] * groundplane[Z];
    shadowMat[3][1] = 0.f - lightpos[Y] * groundplane[W];

    shadowMat[X][2] = 0.f - lightpos[Z] * groundplane[X];
    shadowMat[1][2] = 0.f - lightpos[Z] * groundplane[Y];
    shadowMat[2][2] = dot - lightpos[Z] * groundplane[Z];
    shadowMat[3][2] = 0.f - lightpos[Z] * groundplane[W];

    shadowMat[X][3] = 0.f - lightpos[W] * groundplane[X];
    shadowMat[1][3] = 0.f - lightpos[W] * groundplane[Y];
    shadowMat[2][3] = 0.f - lightpos[W] * groundplane[Z];
    shadowMat[3][3] = dot - lightpos[W] * groundplane[W];

}

/* Find the plane equation given 3 points. */
void defPlano(GLfloat plane[4],GLint v0[3], GLint v1[3], GLint v2[3])
{
    GLfloat vec0[3], vec1[3];
    /* Need 2 vectors to find cross product. */
    vec0[X] = v1[X] - v0[X];
    vec0[Y] = v1[Y] - v0[Y];
    vec0[Z] = v1[Z] - v0[Z];

    vec1[X] = v2[X] - v0[X];
    vec1[Y] = v2[Y] - v0[Y];
    vec1[Z] = v2[Z] - v0[Z];

    /* find cross product to get A, B, and C of plane equation */
    plane[A] = vec0[Y] * vec1[Z] - vec0[Z] * vec1[Y];
    plane[B] = -(vec0[X] * vec1[Z] - vec0[Z] * vec1[X]);
    plane[C] = vec0[X] * vec1[Y] - vec0[Y] * vec1[X];

    plane[D] = -(plane[A] * v0[X] + plane[B] * v0[Y] + plane[C] * v0[Z]);
}

void dibujaObjeto(void)
{

    quad = gluNewQuadric();
    gluQuadricDrawStyle(quad, GLU_FILL);


    //aqui va la esfera
    //GLfloat ambient[] = { 0.5, 0.5, 0.5, 1.0 };
    //GLfloat diffuse[] = { 0.9, 0.9, 0.9, 1.0 };
    GLfloat specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat shininess[] = { 7.0 };
    GLfloat emission[] = {0.5, 0.2, 0.0, 0.0};

    //glMaterialfv(GL_FRONT, GL_AMBIENT, ambient);
    //glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, emission);//color que va a emitimir por si mismo
//    glPushMatrix();
  //      glTranslatef(0, 6.0, 30);
      //  glutSolidSphere(6.0, 68, 68);

    //glPopMatrix();

    //Ventilador

    GLfloat mat_ambient[] = { 0.7, 0.7, 0.7, 1.0 };
    GLfloat mat_diffuse[] = { 0.1, 0.5, 0.8, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat low_shininess[] = { 5.0 };
    GLfloat mat_emission[] = {0.3, 0.2, 0.2, 0.0};

    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);


    glPushMatrix();
        glTranslatef(0, 0, 0);
        glPushMatrix();
            glScalef(1,.3,1);
            glutSolidSphere(6.0, 68, 68);
        glPopMatrix();
        glPushMatrix();
            glRotatef(-90,1,0,0);
            gluCylinder(quad, .5,.5 , 30, 30, 30);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0, 30, 0);
            glScalef(1,.8,1.7);
            glutSolidSphere(4.0, 68, 68);
        glPopMatrix();
        glPushMatrix();
            glTranslatef(0.0, 30, 5.0);
            glRotatef(90,1,0,0);
            glRotatef(-90,1,0,0);
            glScalef(2.3,2.3,.6);
            glutWireSphere(6.0, 15, 20);
        glPopMatrix();
    glPopMatrix();

    //aqui van las aspas
    GLfloat mat_diffusex[] = { 0.9, 0.4, 0.6, 1.0 };
    GLfloat mat_emissionx[] = {0.2, 0.2, 0.9, 0.0};

    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffusex);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, mat_emissionx);

    glPushMatrix();
        glTranslatef(0.0, 30, 5.0);
        glRotatef(rotar,0,0,1);
        glScalef(3.5,.1,.5);
        glutSolidSphere(3.5, 15, 20);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.0, 30, 5.0);
        glRotatef(60,0,0,1);
        glRotatef(rotar,0,0,1);
        glScalef(3.5,.1,.5);
        glutSolidSphere(3.5, 15, 20);
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.0, 30, 5.0);
        glRotatef(120,0,0,1);
        glRotatef(rotar,0,0,1);
        glScalef(3.5,.1,.5);
        glutSolidSphere(3.5, 15, 20);
    glPopMatrix();
}
// cubemap variables entornos para las texturas del cubo, =)
int d1=512;
int d2=512;
static GLint verticesPiso[4][3] = {
    { -d1, 0,  -d1 },
    {  d1, 0,  -d1 },
    {  d1, 0, d1 },
    { -d1, 0, d1 },
};
static GLint verticesTecho[4][3] = {
    { -d1, d1,  d1 },
    {  d1, d1,  d1 },
    {  d1, d1, -d1 },
    { -d1, d1, -d1 },
};
static GLint verticesPisoS[4][3] = {
    { -d1, 0,  d1 },
    {  d1, 0,  d1 },
    {  d1, 0, -d1 },
    { -d1, 0, -d1 },
};
static GLint pared1Vertices[4][3] = {
    { -d1,d2, d1},
    { -d1,0,  d1},
    {  d1,0,  d1},
    {  d1,d2, d1},
};
static GLint pared2Vertices[4][3] = {
    { d1,d2, d1},
    { d1,0,  d1},
    { d1,0, -d1},
    { d1,d2,-d1},
};
static GLint pared3Vertices[4][3] = {

    {  d1,d2,-d1 },
    { d1,0,-d1 },
    { -d1,0,-d1 },
    {  -d1,d2,-d1},
};
static GLint pared4Vertices[4][3] = {
    { -d1,d2,-d1},
    { -d1,0,-d1 },
    {  -d1,0,d1 },
    {  -d1,d2,d1},
};

void dibujaPiso(void)
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 0.0);// como se va a ajustar de cada lado
    glVertex3iv(verticesPiso[0]);
    glTexCoord2f(0.0, 20.0);
    glVertex3iv(verticesPiso[1]);
    glTexCoord2f(20.0, 20.0);
    glVertex3iv(verticesPiso[2]);
    glTexCoord2f(20.0, 0.0);
    glVertex3iv(verticesPiso[3]);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}

void dibujaTecho(void)
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 0.0);// como se va a ajustar de cada lado
    glVertex3iv(verticesTecho[0]);
    glTexCoord2f(0.0, 1.0);
    glVertex3iv(verticesTecho[1]);
    glTexCoord2f(1.0, 1.0);
    glVertex3iv(verticesTecho[2]);
    glTexCoord2f(1.0, 0.0);
    glVertex3iv(verticesTecho[3]);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}

void dibujaPared1(void)
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 0.0);
    glVertex3iv(pared1Vertices[0]);
    glTexCoord2f(0.0, 1.0);
    glVertex3iv(pared1Vertices[1]);
    glTexCoord2f(1.0, 1.0);
    glVertex3iv(pared1Vertices[2]);
    glTexCoord2f(1.0, 0.0);
    glVertex3iv(pared1Vertices[3]);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}
void dibujaPared2(void)
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 0.0);
    glVertex3iv(pared2Vertices[0]);
    glTexCoord2f(0.0, 1.0);
    glVertex3iv(pared2Vertices[1]);
    glTexCoord2f(1.0, 1.0);
    glVertex3iv(pared2Vertices[2]);
    glTexCoord2f(1.0, 0.0);
    glVertex3iv(pared2Vertices[3]);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}

void dibujaPared3(void)
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 0.0);
    glVertex3iv(pared3Vertices[0]);
    glTexCoord2f(0.0, 1.0);
    glVertex3iv(pared3Vertices[1]);
    glTexCoord2f(1.0, 1.0);
    glVertex3iv(pared3Vertices[2]);
    glTexCoord2f(1.0, 0.0);
    glVertex3iv(pared3Vertices[3]);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}

void dibujaPared4(void)
{
    glDisable(GL_LIGHTING);
    glEnable(GL_TEXTURE_2D);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0, 0.0);
    glVertex3iv(pared4Vertices[0]);
    glTexCoord2f(0.0, 1.0);
    glVertex3iv(pared4Vertices[1]);
    glTexCoord2f(1.0, 1.0);
    glVertex3iv(pared4Vertices[2]);
    glTexCoord2f(1.0, 0.0);
    glVertex3iv(pared4Vertices[3]);
    glEnd();
    glDisable(GL_TEXTURE_2D);
    glEnable(GL_LIGHTING);
}

void display(void)
{
    glShadeModel(GL_SMOOTH);//suavisar las lineas

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    posicionLuz[0] = 12*cos(lightAngle);
    posicionLuz[1] = lightHeight;
    posicionLuz[2] = 12*sin(lightAngle);
    posicionLuz[3] = 0.2;//luz posicional o direccional

    shadowMatrix(sombraPiso, planoPiso, posicionLuz);

    glPushMatrix();
    /* mover mouse */
        glRotatef(angle2, 1.0, 0.0, 0.0);
        glRotatef(angle, 0.0, 1.0, 0.0);

    /*light position. */
        glLightfv(GL_LIGHT0, GL_POSITION, posicionLuz);
        glDisable(GL_DEPTH_TEST);
        glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
        dibujaPiso();
        glEnable(GL_DEPTH_TEST);
        glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);//color y profundidad

        glPushMatrix();
            glScalef(1.0, -1.0, 1.0);
            glLightfv(GL_LIGHT0, GL_POSITION, posicionLuz);//Reflejar la luz
            dibujaObjeto();//reflejo

        glPopMatrix();

    /* Switch back to the unreflected light position. */
        glLightfv(GL_LIGHT0, GL_POSITION, posicionLuz);

   glEnable(GL_BLEND);//transparencia
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_CULL_FACE);//n0s muestra las caras
    glCullFace(GL_FRONT);
    glColor4f(1.0, 1.0, 1.0, 0.7);//cambiar el alfa del piso  el .7 es la trasparencia =)
    leerImagen();
    texturaPiso();
    dibujaPiso();
    glColor4f(1.0, 1.0, 1.0, 1);

    leerImagenTecho();
    texturaTecho();
    dibujaTecho();

    leerImagenPared1();
    texturaPared1();
    dibujaPared1();

   leerImagenPared2();
    texturaPared2();
    dibujaPared2();

    leerImagenPared3();
    texturaPared3();
    dibujaPared3();

    leerImagenPared4();
    texturaPared4();
    dibujaPared4();

    glDisable(GL_CULL_FACE);


        glDisable(GL_BLEND);
        dibujaObjeto();
        glDisable(GL_LIGHTING);
        glPushMatrix();
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            glColor4f(0.1, 0.1, 0.1, 0.9);
            glTranslatef(0, 0.2, 0);
            glMultMatrixf((GLfloat *) sombraPiso);
            dibujaObjeto();//Sombra
        glPopMatrix();
        glColor3f(1.0, 1.0, 0.5);
        glTranslatef(posicionLuz[0], posicionLuz[1], posicionLuz[2]);
        //glutSolidSphere(0.8, 20, 20); // luz
        glDisable(GL_BLEND);
    glPopMatrix();

    glutSwapBuffers();
    /*if (bandera==1){
         a=a-b;
    }*/
}

void mouse(int button, int state, int x, int y)
{
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            moving = 1;
            startx = x;
            starty = y;
        }
        if (state == GLUT_UP) {
            moving = 0;
        }
    }
}

void mover(int x, int y)
{
    if (moving) {
        angle = angle + (x - startx);
        angle2 = angle2 + (y - starty);
        startx = x;
        starty = y;
        glutPostRedisplay();
    }
}


void idle(void)
{
    lightAngle += 0.00001;

    if (bandera==0){
        rotar=rotar+0.5;
    }
    glutPostRedisplay();
}

static void
key(unsigned char c, int x, int y)
{
    if (c == 27) {
        exit(0);
    }
    if(c=='a'){
        bandera=0;
    }
    if(c=='p'){
        bandera=1;
    }
    glutPostRedisplay();
}

int
main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH | GLUT_STENCIL | GLUT_MULTISAMPLE);

    glutInitWindowSize(800, 600);

    glutCreateWindow("KafkaPt2");

    glutDisplayFunc(display);
    glutMouseFunc(mouse);
    glutMotionFunc(mover);

    glutIdleFunc(idle);
    glutKeyboardFunc(key);

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_TEXTURE_2D);

    glMatrixMode(GL_PROJECTION);
    gluPerspective(100.0,1.0,10.0,1000.0);
    glMatrixMode(GL_MODELVIEW);
    gluLookAt(0.0, 8.0, 60.0,  /* vista en (0,8,60) */
              0.0, 8.0, 0.0,      /* centro en (0,8,0) */
              0.0, 100.0, 0.0);      /* altura en Y */
    glLightfv(GL_LIGHT0, GL_DIFFUSE, colorLuz);
    //glLightf(GL_LIGHT0, GL_CONSTANT_ATTENUATION, 1);
    glLightf(GL_LIGHT0, GL_LINEAR_ATTENUATION, 0.01);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHTING);

    defPlano(planoPiso, verticesPisoS[1], verticesPisoS[2], verticesPisoS[3]);//Plano para sombra
    glutMainLoop();
    return 0;
}